export const FIREBASE_API_KEY = "AIzaSyCG_P1hP4PjtncSQeq9UFWZMF3mmce9k-w";
export const AUTH_DOMAIN = "legalcdoc-7c056.firebaseapp.com";
export const PROJECT_ID = "legalcdoc-7c056";
export const STORAGE_BUCKET = "legalcdoc-7c056.firebasestorage.app";
export const MESSAGING_SENDER_ID = "901463999689";
export const APP_ID = "1:901463999689:web:e944f333706a3171e9f918";
export const MEASUREMENT_ID = "G-F3WJSKF2XD";
